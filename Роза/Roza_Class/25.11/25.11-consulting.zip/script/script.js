// // window.getComputedStyle()

// let div = document.createElement("div");

// div.style.width = "90%";
// document.body.append(div);

// // console.log(window.getComputedStyle(div).width);

// // console.log(window.getComputedStyle(div, "::after"));

// // getPropertyValue

// // scope

// // 1) global scope

// // global scope

// // 2) function scope
// let dog = "Rex";

// // function name() {
// //   console.log(dog);
// // }
// // name();

// // console.log(dog);

// // 3) block scope

// if (true) {
//   // let / const
//   let num = 30;
// }

// // console.log(num);

// //global scope
// let name = "Joe";
// function foo() {
//   //function scope
//   if (true) {
//     // block scope
//     var num1 = 25;
//     let num2 = 16;
//     const num3 = 12;
//     console.log(name);
//   }

//   console.log(num1);
//   //   console.log(num2);
//   console.log(num3);
// }

// foo();

// const img = [
//   "https://www.gorilladoctors.org/wp-content/uploads/2014/10/empowering2-300x300.jpg",
//   "https://i.pinimg.com/originals/7f/a1/0f/7fa10fdd13baa44a73f0a77ed32e8566.jpg",
//   "https://dogtowndogtraining.com/wp-content/uploads/2012/06/300x300-061-e1340955308953.jpg",
//   "https://dogtowndogtraining.com/wp-content/uploads/2012/06/300x300-03.jpg",
// ];

// // global scope
// for (let i = 0; i < img.length; i++) {
//     //block scope
//   let newImg = document.createElement("img");
//   newImg.setAttribute("src", img[i]);
//   newImg.setAttribute("alt", "Nature");

//   document.body.append(newImg);

//   newImg.onclick = () => {
//     // function scope
//     alert(img[i]);
//   };
// }

// let nums = [2, 3, 4, 5, 6];

// function createP(array) {
//   for (let num of array) {
//     let div = document.createElement("div");

//     let p = document.createElement("p");
//     p.innerText = num;

//     let increment = document.createElement("button");
//     increment.innerText = "+";

//     let decrement = document.createElement("button");
//     decrement.innerText = "-";

//     div.append(increment, p, decrement);
//     div.classList.add("flex");

//     document.body.append(div);
//     p.onclick = () => {
//       p.innerText = p.textContent ** 2;
//       //   Math.pow(p.textContent, 2)
//       //   Math.sqrt(number);
//     };

//     // console.log(typeof p.textContent);
//     increment.onclick = () => {
//       p.innerText = +p.textContent + 1;
//     };
//     decrement.onclick = () => {
//       p.innerText = p.textContent - 1;
//     };
//   }
// }

// createP(nums);

// addEventListener

//removeEventListener

// const btn = document.createElement("button");
// btn.innerText = "Click me!";

// document.body.append(btn);

// // callback function
// btn.addEventListener("click", func1);
// btn.addEventListener("click", func2);
// btn.addEventListener("click", func3);

// // hoisting

// function func1() {
//   alert("1");
//   btn.removeEventListener("click", func1);
// }
// function func2() {
//   alert("2");
//   btn.removeEventListener("click", func2);
// }
// function func3() {
//   alert("3");
// }

// 5) У нас есть кнопка в html документе. С помощью скриптов сделайте след. логику:
// 1)добавьте 3 event listener-а на кнопку, которые выводят на экран 1,2,3. (первая функция выводит цифру 1, вторая - 2, и последняя 3),
// 2) Пусть при первом клике на кнопку сработают все 3 функции и при этом func1 и func2 отвяжутся от элемента. И при следующих кликах будет срабатывать только функция func3, которую мы не отвязываем.

let btn1 = document.createElement("button");
btn1.innerText = "start";
let btn2 = document.createElement("button");

btn2.innerText = "end";
let p = document.createElement("p");

document.body.append(btn1, btn2, p);

btn1.addEventListener("click", () => {
  document.addEventListener("mousemove", move);
});

btn2.addEventListener("click", () => {
  document.removeEventListener("mousemove", move);
});

function move(event) {
  p.innerText = `X:${event.pageX}  Y:${event.pageY}`;
}
